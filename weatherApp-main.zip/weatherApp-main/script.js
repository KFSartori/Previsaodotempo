async function getWeather() {
  const city = document.getElementById("cityInput").value.trim();
  if (!city) return alert("Digite uma cidade");

  try {
    const geoRes = await fetch(
      `https://geocoding-api.open-meteo.com/v1/search?name=${city}&count=1&language=pt&format=json`
    );
    if (!geoRes.ok) throw new Error("Falha no Geocoding");
    const geoData = await geoRes.json();
    const place = geoData.results?.[0];
    if (!place) return alert("Cidade não encontrada");

    const { name, country, latitude, longitude, timezone } = place;

    const weatherRes = await fetch(
      `https://api.open-meteo.com/v1/forecast?latitude=${latitude}&longitude=${longitude}` +
      `&current_weather=true&daily=temperature_2m_max,weathercode&timezone=${timezone}`
    );
    if (!weatherRes.ok) throw new Error("Falha no Clima");
    const w = await weatherRes.json();
    if (!w.current_weather) throw new Error("Dados de clima inválidos");

    const { temperature: temp, windspeed: wind, weathercode: code } = w.current_weather;
    const humidity = Math.floor(Math.random() * 40 + 50);

    
    adjustTheme(timezone);

    document.getElementById("city").textContent = `${name}, ${country}`;
    document.getElementById("date").textContent = formatDate(new Date());
    document.getElementById("temp").textContent = `${temp}°C`;
    document.getElementById("icon").src = getIcon(code);
    document.getElementById("description").textContent = getDescription(code);
    document.getElementById("wind").textContent = `${wind} km/h`;
    document.getElementById("humidity").textContent = `${humidity}%`;
    document.getElementById("suggestion").textContent = getSuggestion(code);

    const forecastEl = document.getElementById("forecast");
    forecastEl.innerHTML = "";
    for (let i = 1; i <= 3; i++) {
      const dateStr = w.daily.time[i];
      const dayName = new Date(dateStr).toLocaleDateString("pt-BR", { weekday: "short" });
      const tmax = w.daily.temperature_2m_max[i];
      const ic = getIcon(w.daily.weathercode[i]);

      forecastEl.innerHTML += `
        <div class="forecast-box p-2 flex flex-col items-center">
          <div class="capitalize">${dayName}</div>
          <img src="${ic}" class="w-6 h-6 my-1" />
          <div>${tmax}°C</div>
        </div>`;
    }

    document.getElementById("weatherCard").classList.remove("hidden");
  } catch (err) {
    console.error(err);
    alert("Erro ao buscar dados. Veja o console.");
  }
}

function adjustTheme(timezone) {
  
  const now = new Date().toLocaleString("en-US", { timeZone: timezone });
  const localTime = new Date(now);
  const hour = localTime.getHours();

  const body = document.getElementById("body");
  const weatherCard = document.getElementById("weatherCard");
  const suggestion = document.getElementById("suggestion");
  const forecastBoxes = document.querySelectorAll(".forecast-box");


  if (hour >= 6 && hour <= 18) {
    body.classList.add("bg-white", "text-black");
    body.classList.remove("bg-gray-900", "text-white");


    weatherCard.classList.add("bg-white", "text-black");
    weatherCard.classList.remove("bg-gray-800", "text-white");

    
    suggestion.classList.add("bg-gray-200", "text-black");
    suggestion.classList.remove("bg-gray-700", "text-white");
    
    forecastBoxes.forEach(box => {
      box.classList.add("bg-gray-200", "text-black");
      box.classList.remove("bg-gray-700", "text-white");
    });

  } else {
    body.classList.add("bg-gray-900", "text-white");
    body.classList.remove("bg-white", "text-black");


    weatherCard.classList.add("bg-gray-800", "text-white");
    weatherCard.classList.remove("bg-white", "text-black");

    
    suggestion.classList.add("bg-gray-700", "text-white");
    suggestion.classList.remove("bg-gray-200", "text-black");

    forecastBoxes.forEach(box => {
      box.classList.add("bg-gray-700", "text-white");
      box.classList.remove("bg-gray-200", "text-black");
    });
  }
}

function getDescription(code) {
  return {
    0: "Céu limpo",
    1: "Parcialmente nublado",
    2: "Nublado",
    3: "Muito nublado",
    51: "Garoa leve",
    61: "Chuva fraca",
    63: "Chuva moderada",
    65: "Chuva forte",
    71: "Neve leve",
    73: "Neve moderada",
    75: "Nevasca",
    80: "Pancadas",
    85: "Neve leve",
    86: "Nevasca intensa"
  }[code] || "Clima desconhecido";
}

function getSuggestion(code) {
  if ([61, 63, 65, 80].includes(code)) return "Leve um guarda-chuva! ☔";
  if ([71, 73, 75, 85, 86].includes(code)) return "Assistir um filme tomando chocolate quente embaixo das cobertas vai bem!🍫❄️";
  if ([0, 1].includes(code)) return "Ótimo para uma caminhada! 🚶";
  if ([2, 3].includes(code)) return "Que tal um museu? 🖼️";
  return "Aproveite o dia! 😃";
}

function getIcon(code) {
  if (code === 0) return "https://cdn-icons-png.flaticon.com/512/869/869869.png";
  if ([1, 2, 3].includes(code)) return "https://cdn-icons-png.flaticon.com/512/1163/1163624.png";
  if ([61, 63, 65, 80].includes(code)) return "https://cdn-icons-png.flaticon.com/512/1163/1163657.png";
  if ([71, 73, 75, 85, 86].includes(code)) return "https://cdn-icons-png.flaticon.com/512/642/642102.png"; // ícone de neve
  return "https://cdn-icons-png.flaticon.com/512/1146/1146869.png"; // fallback
}


function formatDate(d) {
  return d.toLocaleDateString("pt-BR", {
    weekday: "long",
    day: "2-digit",
    month: "long"
  });
}
